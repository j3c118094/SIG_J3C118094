<?php

header("Location: ../");

?>