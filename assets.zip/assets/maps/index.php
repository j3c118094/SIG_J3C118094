<?php

header("Location: ../../");

?>