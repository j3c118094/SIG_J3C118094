# WEBGIS Data Fasilitas Kesehatan Kab. Bekasi
WebGis App ini dibuat untuk memenuhi Tugas Mata Kuliah **Sistem Informasi Geografis**.
Alan Raihan Maulana - J3C118094.
### Daftar Fitur

  - Menampilkan WebGis dengan data setelah melalui proses analsis pada QGIS
  - Menampilkan peta yang telah dibuat dan diexport dari QGIS dengan Layout


Tambahan Fitur :
  - IP GeoLocation
  - Multiple web maps
  - Unduhan langsung dari data yang digunakan

  
### Catatan

  Jika ada kesalahan dari data yang digunakan silahkan kunjungi dan hubungi [Badan Pusat Statistika Kabupaten bekasi](https://bekasikab.bps.go.id/).
  Jika ada penyalahgunaan dari data yang disediakan dari website ini, tanggung jawab berada sepenuhnya pada pengguna.
